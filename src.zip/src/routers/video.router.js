import express from "express";
import models from "../common/sequelize/init.sequelize.js";

const videoRouter = express.Router()


videoRouter.get('video-list', async(req,res,next) => {

    try {

        const videos = await models.videos.findAll({raw:true}); 
      
        res.json(videos);

    } catch (error) {
        console.log(error); 
        res.status(500).json({error}); 
        
    }
})


export default videoRouter


